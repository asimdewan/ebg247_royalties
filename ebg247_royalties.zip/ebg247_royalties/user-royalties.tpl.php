<div class="royalties-dashboard">
  <div><h2 style="color:#0000CC"><img src="/drupal-public/money-icon.jpg" />Sales and Payment Report</h2></div>

  <h3>Books Sold</h3>
  <?php print $sales_table; ?>
<div style="color:#009900">
  <h3><sup>*</sup>Net royalties: <?php print $royalties['gross_royalties']['amount_formatted']; ?></h3>
<em><sup>*</sup>Processing fees are charged by Brain Tree and are estimated to be
  2.9% plus 30 cents per transaction.</em>
  <em><sup>**</sup>Royalties very due to U.S. International Tax Treaty.</em>
</div>

  <h3>Payments Made</h3>
  <?php print $payments_table; ?>
<div style="color:#009900">
  <h3><sup>*</sup>Net royalties: <?php print $royalties['net_royalties']['amount_formatted']; ?></h3>
</div>

  <em><sup>*</sup>Processing fees are charged by Brain Tree and are estimated to be
  2.9% plus 30 cents per transaction.</em>
  <em><sup>**</sup>Royalties very due to U.S. International Tax Treaty.</em>
</div>
